#include "cfear_radarodometry/odometrykeyframefuser.h"
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
#include <chrono>
#include <thread>


// imu deque 的数据长度
const int queueLength = 2000;

namespace CFEAR_Radarodometry {

visualization_msgs::Marker GetDefault(){
  visualization_msgs::Marker m;
  m.color.r = 0;
  m.color.g = 0;
  m.color.b = 1;
  m.color.a = 1;
  m.type = visualization_msgs::Marker::LINE_LIST;
  m.id = 0;
  m.scale.x = 0.1;
  m.action = visualization_msgs::Marker::ADD;
  m.lifetime = ros::Duration(0);
  m.header.frame_id ="world";
  m.header.stamp = ros::Time::now();
  return m;
}

OdometryKeyframeFuser::OdometryKeyframeFuser(const Parameters& pars, bool disable_callback) : par(pars), nh_("~") {
  assert (!par.input_points_topic.empty() && !par.scan_registered_latest_topic.empty() && !par.scan_registered_keyframe_topic.empty() && !par.odom_latest_topic.empty() && !par.odom_keyframe_topic.empty() );
  assert(par.res>0.05 && par.submap_scan_size>=1 );
  //radar_reg =
  radar_reg = boost::shared_ptr<CFEAR_Radarodometry::n_scan_normal_reg>(new n_scan_normal_reg(Str2Cost(par.cost_type),
                                                                                              Str2loss(par.loss_type_),
                                                                                              par.loss_limit_,
                                                                                              par.weight_opt));

  radar_reg->SetD2dPar(par.covar_scale_,par.regularization_);

  //Eigen::Affine3d 类型表示的是一个 4x4 的仿射变换矩阵 T ，同时表示旋转和平移
  Tprev_fused = Eigen::Affine3d::Identity();
  Tcurrent = Eigen::Affine3d::Identity();
  cov_current = Covariance::Identity();
  T_prev = Eigen::Affine3d::Identity();
  Tmot = Eigen::Affine3d::Identity();

  // pub = nh_.advertise<pcl::PointCloud<pcl::PointXYZI> >("radar_cloud_y", 1000);
  pose_current_publisher = nh_.advertise<nav_msgs::Odometry>(par.odom_latest_topic,50);
  pose_keyframe_publisher = nh_.advertise<nav_msgs::Odometry>(par.odom_keyframe_topic,50);
  pubsrc_cloud_latest = nh_.advertise<pcl::PointCloud<pcl::PointXYZI> >(par.scan_registered_latest_topic, 1000);
  pub_cloud_keyframe = nh_.advertise<pcl::PointCloud<pcl::PointXYZI> >(par.scan_registered_keyframe_topic, 1000);

  imuCircularBuffer_ = ImuCircularBuffer((int)(par.imu_frequency * 1.5));
  if(!disable_callback) {
    cout<<"subscribe<sensor_msgs::PointCloud2>("<<par.input_points_topic<<")"<<endl;
    ///par.input_points_topic 是 Navtech/Filtered
    pointcloud_callback = nh_.subscribe<sensor_msgs::PointCloud2>(par.input_points_topic, 1000,
                                                                  &OdometryKeyframeFuser::pointcloudCallback, this,
                                                                  ros::TransportHints().tcpNoDelay(true));
    imu_sub_ = nh_.subscribe<sensor_msgs::Imu>(par.imu_topic, 2000, &OdometryKeyframeFuser::ImuCallback, this);
  }
  else
    cout<<"callback disabled"<<endl;
}
/*OdometryKeyframeFuser::~OdometryKeyframeFuser(){
  //cout<<"destruct fuser"<<endl;
  keyframes_.clear();
  ///  cout<<"destructed fuser"<<endl;
}*/



bool OdometryKeyframeFuser::KeyFrameBasedFuse(const Eigen::Affine3d& diff, bool use_keyframe, double min_keyframe_dist, double min_keyframe_rot_deg){

  if(!use_keyframe)
    return true;
  //eulerAngles() 获取欧拉角表示的旋转部分，0 1 2 分别表示绕x，y，z
  Eigen::Vector3d Tmotion_euler = diff.rotation().eulerAngles(0,1,2);
  CFEAR_Radarodometry::normalizeEulerAngles(Tmotion_euler);
  bool fuse_frame = false;
  //cout<<"diff (trans[m]/rot[deg])=("<<diff.translation().norm()<<"/"<<diff.rotation().eulerAngles(0,1,2).norm()*180.0/M_PI<<") limit=("<<min_keyframe_dist_<<"/"<<min_keyframe_rot_deg_<<")"<<endl;
  if(diff.translation().norm()>min_keyframe_dist || Tmotion_euler.norm()>(min_keyframe_rot_deg*M_PI/180.0))
    fuse_frame = true;
  return fuse_frame;
}

//check速度和加速度是否超过阈值
bool OdometryKeyframeFuser::AccelerationVelocitySanityCheck(const Eigen::Affine3d& Tmot_prev, const Eigen::Affine3d& Tmot_curr) {
  const double dt = 0.25 ; // 4Hz
  const double vel_limit = 200; // m/s
  const double acc_limit = 200; // m/s
  //计算速度向量的范数
  const double vel = (Tmot_curr.translation()/dt).norm();
  const double acc = ((Tmot_curr.translation() - Tmot_prev.translation())/(dt*dt)).norm();

  //cout<<"vel: "<<vel<<", acc: "<<acc<<endl;
  if(acc>acc_limit){
    cout<<"acceleration exceeds limit"<<acc<<" > "<<acc_limit<<endl;
    return false;
  }
  else if(vel>vel_limit){
    cout<<"velocity exceeds limit"<<vel<<" > "<<vel_limit<<endl;
    return false;
  }
  else return true;

}

//两个变换之间插值
Eigen::Affine3d OdometryKeyframeFuser::Interpolate(const Eigen::Affine3d &T2, double factor, const Eigen::Affine3d &T1) {
  // std::cout<<"factor="<<factor<<std::endl;
  Eigen::Affine3d pose;
  Eigen::Quaterniond q1(T1.linear());
  Eigen::Quaterniond q2(T2.linear());
  pose.linear() = (q1.slerp(factor, q2)).toRotationMatrix();
  Eigen::Vector3d tdiff = T2.translation() - T1.translation();
  pose.translation() = T1.translation() + tdiff * factor;
  return pose;
}
//一个坐标系的点投影到另一个坐标系
pcl::PointXYZI OdometryKeyframeFuser::Transform(const Eigen::Affine3d& T, pcl::PointXYZI& p){
  Eigen::Vector3d v(p.x,p.y,p.z);
  Eigen::Vector3d v2 = T*v;
  pcl::PointXYZI p2;
  p2.x = v2(0);
  p2.y = v2(1);
  p2.z = v2(2);
  p2.intensity = p.intensity;
  return p2;
}
//将输入的信息格式化为 nav_msgs::Odometry 类型的 ROS 消息，里程计
nav_msgs::Odometry OdometryKeyframeFuser::FormatOdomMsg(const Eigen::Affine3d& T, const Eigen::Affine3d& Tmot, const ros::Time& t, Matrix6d& Cov){
  nav_msgs::Odometry odom_msg;

  //double d = Tmot.translation().norm();
  //Eigen::MatrixXd 创建一个矩阵
  Eigen::MatrixXd cov_1_36(Cov);
  //reg_cov(0,0) = reg_cov(1,1) = (d*0.02)*(d*0.02);
  //reg_cov(5,5) = (d*0.005)*(d*0.005);
  cov_1_36.resize(1,36);
  for(int i=0;i<36;i++){
    odom_msg.pose.covariance[i] = cov_1_36.data()[i];
  }

  odom_msg.header.stamp = t;
  odom_msg.header.frame_id = par.odometry_link_id;
  odom_msg.child_frame_id = "sensor";
  //用于将 Eigen 库中的 Affine3d 类型的姿态转换为 ROS 中的 geometry_msgs::Pose 消息类型
  tf::poseEigenToMsg( T, odom_msg.pose.pose);
  return odom_msg;
}


/**
 * @name getradarPose()
 * @brief 得到机器人在当前激光点的姿态，返回是否成功
 * @param point_index  激光点的序号
 * @param _timestamp   当前激光点的时间戳
 * @param quat_out  输出四元数
*/
bool OdometryKeyframeFuser::getradarPose(int point_index, ros::Time &_timestamp, Eigen::Quaterniond &quat_out)
{
  static int index_front = 0;
  static int index_back = 0;
  static ros::Time timestamp_front;
  static ros::Time timestamp_back;
  static Eigen::Quaterniond quat_front, quat_back;

  static bool index_updated_flag = false;
  static bool predict_orientation_flag = false;

  if (point_index == 0)
  {
    predict_orientation_flag = false;
    int i = 0;
    while (_timestamp < imuCircularBuffer_[i].header.stamp)
    {
      i++;
    }
    index_front = i - 1;
    index_back = i;
    index_updated_flag = true;
  }
  else
  {
    while (predict_orientation_flag == false
            && _timestamp > imuCircularBuffer_[index_front].header.stamp
            && _timestamp > imuCircularBuffer_[index_back].header.stamp)
    {
      index_front--;
      index_back--;

      if (index_front < 0)
      {
        //use prediction
        predict_orientation_flag = true;
        index_front++;
        index_back++;
      }

      index_updated_flag = true;
    }
  }

  if (index_updated_flag == true)
  {
    //cout << "index updated: " << index_front << " " << index_back << endl;
    timestamp_front = imuCircularBuffer_[index_front].header.stamp;
    timestamp_back = imuCircularBuffer_[index_back].header.stamp;
    quat_front = Eigen::Quaterniond(imuCircularBuffer_[index_front].orientation.w, imuCircularBuffer_[index_front].orientation.x, imuCircularBuffer_[index_front].orientation.y, imuCircularBuffer_[index_front].orientation.z);
    quat_back = Eigen::Quaterniond(imuCircularBuffer_[index_back].orientation.w, imuCircularBuffer_[index_back].orientation.x, imuCircularBuffer_[index_back].orientation.y, imuCircularBuffer_[index_back].orientation.z);

    index_updated_flag = false;
  }

  float alpha = (float)(_timestamp.toNSec() - timestamp_back.toNSec()) / (timestamp_front.toNSec() - timestamp_back.toNSec());

  if (alpha < 0)
  {
    return false;
  }

  // 球面线性插值
  // Slerp.
  quat_out = quat_back.slerp(alpha, quat_front);

  //先改成不用线性插值
  // quat_out = quat_front;

  return true;
}

//将输入的点云，由变换，转换为新的点云     这里的t是pointcloud2 Navtech/Filtered 的stamp
pcl::PointCloud<pcl::PointXYZI> OdometryKeyframeFuser::FormatScanMsg(pcl::PointCloud<pcl::PointXYZI>& cloud_in, Eigen::Affine3d& T){
  pcl::PointCloud<pcl::PointXYZI> cloud_out;
  pcl::transformPointCloud(cloud_in, cloud_out, T);
  cloud_out.header.frame_id = par.odometry_link_id;
  cloud_out.header.stamp = cloud_in.header.stamp;
  return cloud_out;
}


//把四元数转化为只绕z轴的四元数
Eigen::Quaterniond OdometryKeyframeFuser::projectToYaw(const Eigen::Quaterniond& q) {
    // 将四元数转换为欧拉角
    Eigen::Vector3d euler = q.toRotationMatrix().eulerAngles(0, 1, 2); // yaw, pitch, roll

    // 将roll和pitch置为0
    euler[1] = euler[2] = 0; // pitch and roll set to 0

    // 创建新的四元数
    Eigen::Quaterniond new_quat(Eigen::AngleAxisd(euler[0], Eigen::Vector3d::UnitZ()));

    return new_quat;
}

//旋转矩阵转成绕z轴的欧拉角（弧度制）
double OdometryKeyframeFuser::toZRotation(const Eigen::Matrix2d& R) {
    // 提取旋转矩阵的第一行和第二行
    Eigen::Vector2d row1 = R.row(0);
    Eigen::Vector2d row2 = R.row(1);

    // 计算第一行和第二行的单位向量与x轴和y轴的夹角
    double angle = std::atan2(row2(0), row1(0));
    double z_rotation;
    // 计算两个夹角的平均值作为绕z轴旋转的角度
    if (abs(row1(0)) < 1e-6 && row2(0) > 0 )//		tana =  sina / cosa;
		{
			z_rotation = M_PI_2;
		}
    else if(abs(row1(0)) < 1e-6 && row2(0) < 0 )//		tana =  sina / cosa;
		{
			z_rotation = -M_PI_2;
		}
    else
    {
      z_rotation = angle ;
    }  
    return z_rotation;
}

// void OdometryKeyframeFuser::Compensate_rotation(pcl::PointCloud<pcl::PointXYZI>& cloud, const Eigen::Affine3d& Tmotion, bool ccw, const ros::Time& time)
// {
//   std::vector<double> mot;
//   CFEAR_Radarodometry::Affine3dToVectorXYeZ(Tmotion, mot); // mot 是 dx, dy, 和绕z轴的欧拉角（弧度制）
//   // std::cout<<"Tmotion:"<<Tmotion.matrix()<<std::endl;
//   // Eigen::Vector3d eul = Tmotion.linear().eulerAngles(0,1,2);
//   // Eigen::Matrix2d r =  Tmotion.linear().block<2, 2>(0,0);
//   // std::cout<<"\033[1;33m"<<"sita_z:"<<toZRotation(r)*M_PI/180.0<<std::endl;
//   // std::cout<<"\033[1;32m"<<"Tmotion.eulerAngles:"<<eul(2)<<std::endl;

//   for (const auto& element : mot) {
//     std::cout << "mot:"<<element << " ";
//   } 
//   std::cout << std::endl;
  
//   //在这里修改！！！！！！！！！！！！！！！
//   ros::Time TimeStamp = time;
//   current_scan_time_start_ = time.toSec();
//   current_scan_time_end_ = current_scan_time_start_ + 4.0;

//   Eigen::Quaterniond point_quat_current;
//   Eigen::Quaterniond point_quat_relative;
//   Eigen::Matrix2d R;
//   double sita;
//   double angle = M_PI / 2.0;
//   Eigen::Quaterniond rotation_quat(cos(angle / 2), 0, 0, sin(angle / 2)); // Z轴顺时针旋转π/2的四元数
//   Eigen::Quaterniond quat_int(1, 0, 0, 0);

//   //2024/3/27 这里把R得到的方式变为由积分角速度得到
//   // 进行两次乘法得到绕Z轴顺时针旋转π的四元数
//   Eigen::Quaterniond rotated_quat = rotation_quat * rotation_quat;
//   //初始位姿
//   if(par.flag_first == true)
//   {
//     if (getradarPose(0, TimeStamp, point_quat_last) == true)
//     { 
//       point_quat_last = rotated_quat * point_quat_last;
//       point_quat_relative =  point_quat_last;
//       Eigen::Quaterniond point_quat_wz = projectToYaw(point_quat_relative);
//       Eigen::Matrix3d rotation_matrix = point_quat_wz.toRotationMatrix();
//       R = rotation_matrix.block<2, 2>(0,0);
//       sita = toZRotation(R)*M_PI/180.0;
//       par.flag_first = false;
//       std::cout<<"flag_first:"<<par.flag_first<<std::endl;
//     }
//   }
//   else
//   {
//     if (getradarPose(0, TimeStamp, point_quat_current) == true)
//     {
      
//       point_quat_current = rotation_quat * point_quat_current;
//       point_quat_relative = point_quat_last.inverse() * point_quat_current;
//       point_quat_last = point_quat_current;
//       Eigen::Quaterniond point_quat_wz = projectToYaw(point_quat_relative);
//       Eigen::Matrix3d rotation_matrix = point_quat_wz.toRotationMatrix();
//       R = rotation_matrix.block<2, 2>(0,0);
//       sita = toZRotation(R)*M_PI/180.0;
//     }
//   }
//    mot[2] = sita;

//   for (const auto& element : mot) {
//     std::cout << "mot modified:"<<element << " ";
//   } 
//   std::cout << std::endl;


//   //测试一下得到的imu朝向
//   Eigen::Quaterniond point_quat;
//   if (getradarPose(0, TimeStamp, point_quat) == true)
//     {

//       Eigen::Quaterniond point_quat_wz = projectToYaw(point_quat);
//       Eigen::Matrix3d rotation_matrix = point_quat_wz.toRotationMatrix();
//       R = rotation_matrix.block<2, 2>(0,0);
//       sita = toZRotation(R)*M_PI/180.0;
//       std::cout << "sita:            "<<sita<<std::endl;
//     }
  
//   // Eigen::Quaterniond quat(1, 0, 0, 0);
//   // // 将四元数转换为欧拉角（Roll-Pitch-Yaw）
//   // Eigen::Vector3d euler_angles = quat.toRotationMatrix().eulerAngles(0, 1, 2);
//   // // 输出偏航角（Yaw）
//   // std::cout << "Yaw of unit quaternion: " << euler_angles(2) << std::endl;


//   Compensate_rotation(cloud, mot, ccw , time);
// }


void OdometryKeyframeFuser::Compensate_rotation(pcl::PointCloud<pcl::PointXYZI>& cloud, const Eigen::Affine3d& Tmotion, bool ccw, const ros::Time& time)
{
  std::vector<double> mot;
  CFEAR_Radarodometry::Affine3dToVectorXYeZ(Tmotion, mot); // mot 是 dx, dy, 和绕z轴的欧拉角（弧度制）
  // std::cout<<"Tmotion:"<<Tmotion.matrix()<<std::endl;
  // Eigen::Vector3d eul = Tmotion.linear().eulerAngles(0,1,2);
  // Eigen::Matrix2d r =  Tmotion.linear().block<2, 2>(0,0);
  // std::cout<<"\033[1;33m"<<"sita_z:"<<toZRotation(r)*M_PI/180.0<<std::endl;
  // std::cout<<"\033[1;32m"<<"Tmotion.eulerAngles:"<<eul(2)<<std::endl;

  for (const auto& element : mot) {
    std::cout << "mot:"<<element << " ";
  } 
  std::cout << std::endl;
  
  //在这里修改！！！！！！！！！！！！！！！
  ros::Time TimeStamp = time;
  current_scan_time_start_ = time.toSec()-0.25;  
  current_scan_time_end_ = current_scan_time_start_ + 0.25;

  
  Eigen::Quaterniond point_quat_current;
  Eigen::Quaterniond point_quat_relative;
  Eigen::Matrix2d R;
  double sita;
  double angle = M_PI / 2.0;
  Eigen::Quaterniond rotation_quat(cos(angle / 2), 0, 0, sin(angle / 2)); // Z轴顺时针旋转π/2的四元数
  Eigen::Quaterniond quat_int(1, 0, 0, 0);
  

  //2024/3/27 这里把R得到的方式变为由积分角速度得到
  //初始位姿
  if (PruneImuDeque() == true)
  {
    if(par.flag_first == true)
    {
      point_quat_relative =  quat_int;
      Eigen::Quaterniond point_quat_wz = projectToYaw(point_quat_relative);
      Eigen::Matrix3d rotation_matrix = point_quat_wz.toRotationMatrix();
      R = rotation_matrix.block<2, 2>(0,0);
      sita = toZRotation(R);     //弧度
      par.flag_first = false;
      // std::cout<<"flag_first:"<<par.flag_first<<std::endl;
      deta_rot_z = 0.0;
      // for(int i =0; i <25 ; ++i)
      // { 
      //   double rotZCur = 0;
      //   current_point_time = current_scan_time_start_ + i * 0.01;
      //   ComputeRotation(current_point_time, &rotZCur);
      //   std::cout<<"rotZCur in first"<< rotZCur<<std::endl;
      //   // deta_rot_z = deta_rot_z + rotZCur;
      // }
      // deta_rot_z = deta_rot_z * M_PI / 180.0;
      double rotZCur = 0;
      ComputeRotation(current_scan_time_end_, &rotZCur);
      deta_rot_z = rotZCur;
      mot[2] = deta_rot_z;
    }
    else
    { 
      // mot[2] = deta_rot_z;
      // std::cout << "mot[2]:"<<mot[2]<<std::endl;
      deta_rot_z = 0.0;
      // for(int i =0; i <25 ; ++i)
      // { 
      //   double rotZCur = 0;
      //   current_point_time = current_scan_time_start_ + i * 0.01;
      //   ComputeRotation(current_point_time, &rotZCur);
      //   std::cout<<"rotZCur:"<< rotZCur<<std::endl;
      //   // deta_rot_z = deta_rot_z + rotZCur;
      //   // std::cout<<"deta_rot_z not in first"<< deta_rot_z<<std::endl;
      // }
      double rotZCur = 0;
      ComputeRotation(current_scan_time_end_, &rotZCur);
      deta_rot_z = rotZCur;
      // deta_rot_z = deta_rot_z * M_PI / 180.0;
      mot[2] = deta_rot_z; // 绕z轴的弧度
    }
  }
  for (const auto& element : mot) {
    std::cout << "mot modified:"<<element << " ";
  } 
  std::cout << std::endl;

  m_imu.assign(mot.begin(), mot.end());
  Compensate_rotation(cloud, mot, ccw , time);
}
//ccw radar数据是否逆时针 ,mulran&oxford都是true,这个compensate是匀速模型
void OdometryKeyframeFuser::Compensate_rotation(pcl::PointCloud<pcl::PointXYZI>& cloud, const std::vector<double>& mot, bool ccw, const ros::Time& time)
{
  // if (imuCircularBuffer_.size() > frame_duration.toSec() * par.imu_frequency * 1.5)
  // {
  // }
  // Eigen::Matrix2d R = getScaledRotationMatrix(mot, 1).block<2,2>(0,0);
  for ( int i=0; i<cloud.size();i++) {
    pcl::PointXYZI p = cloud.points[i];
    //逆时针：0~pi 对应 0.5~0 ; -pi~0对应 0~-0.5
    // ccw is true 
    // std::cout<<"ccw:"<<ccw<<std::endl;
    double d = GetRelTimeStamp(p.x, p.y, ccw);
    Eigen::Vector2d peig(p.x,p.y);
    // std::cout<<"p.x:"<<p.x<<"p.y:"<<p.y<<std::endl;
    // std::this_thread::sleep_for(std::chrono::seconds(10));

    //把这个改成imu的就行了
    Eigen::Vector2d t = getScaledTranslationVector(mot, d).block<2,1>(0,0);
    Eigen::Matrix2d R = getScaledRotationMatrix(mot, d).block<2,2>(0,0);
    // d = 0.5 - d;
    // Eigen::Matrix2d R_i = d * R;

    ros::Time point_timestamp = time ;
    // std::cout<<"--------------------------------------------------------------------"<<std::endl;
    // std::cout<<"\033[1;33m"<<"point_timestamp:"<<point_timestamp<<std::endl;
    // std::cout<<"\033[1;34m"<<"time:"<<time<<std::endl;
    //是0.5 ->0 -> -0.5的顺序,  对应的范围是 0->pi->-pi->0
    // std::cout<<"\033[1;35m"<<"d:"<<d<<std::endl;
    // std::cout<<"\033[1;35m"<<"ros::Duration(d):"<<ros::Duration(d)<<std::endl;
    // std::cout<<"\033[1;31m"<<"t:"<<t<<std::endl;
    // std::cout<<"\033[1;32m"<<"R :"<<R<<std::endl;
    // std::cout<<"\033[1;32m"<<"R :"<<toZRotation(R)<<std::endl;
    // Eigen::Quaterniond point_quat;
    // if (getradarPose(i, point_timestamp, point_quat) == true)
    // {
    //   Eigen::Quaterniond point_quat_wz = projectToYaw(point_quat);
    //   Eigen::Matrix3d rotation_matrix = point_quat_wz.toRotationMatrix();
    // //   R = rotation_matrix.block<2, 2>(0,0);
    // //   // std::cout<<"\033[1;31m"<<"R modified:"<<R<<std::endl;
    // //   Eigen::Matrix2d R_modified;
    // //   R_modified << R(0, 0), -R(0, 1),
    // //              -R(1, 0), R(1, 1);
    // //   R = -R_modified;

    // //   // std::cout<<"\033[1;31m"<<"R modified:"<<R<<std::endl;
    // //   // std::cout<<"\033[1;31m"<<"R modified:"<<toZRotation(R)<<std::endl;

    // }
    Eigen::Vector2d peig_transformed =  R *peig + t;
    // Eigen::Vector2d peig_transformed = R_i*peig ;
    cloud.points[i].x = peig_transformed(0,0);
    cloud.points[i].y = peig_transformed(1,0);
  }
  // pcl::PointCloud<pcl::PointXYZI> cloud_cys;
  // // 遍历输入点云，筛选出 y > 0 的点
  // for (size_t i = 0; i < cloud.points.size(); ++i)
  // {
  //     if (cloud.points[i].y > 0)
  //     {
  //         cloud_cys.points.push_back(cloud.points[i]);
  //     }
  // }
  // pcl::PointCloud<pcl::PointXYZI> cld_cys = FormatScanMsg(cloud_cys, Tcurrent);
  // // cloud_out.header.frame_id = "world";
  // // cloud_out.header.stamp = time.toSec();
  // // 将新的点云转换为 ROS 消息并发布出去
  // // sensor_msgs::PointCloud cloud_msg;
  // // pcl::toROSMsg(cloud_out, cloud_msg);
  // // cloud_msg.header.frame_id = "world";
  // // cloud_msg.header.stamp = time;
  // pub.publish(cld_cys);
}

// 修剪imu队列，以获取包含 当前帧雷达时间 的imu数据及转角
bool OdometryKeyframeFuser::PruneImuDeque()
{
    std::lock_guard<std::mutex> lock(imu_lock_);
    std::cout<<"imu_queue_.size() before prune:"<<imu_queue_.size()<<std::endl;
    // for (const auto& i : imu_queue_) {
        // 打印 IMU 消息的内容，根据需要进行适当的操作
        // std::cout << "IMU message:";
        // std::cout << std::fixed << std::setprecision(9) << i.header.stamp.toSec() << std::endl;
        // 根据需要打印其他信息
    // }

    // std::cout<<"imu_queue_.front():"<< std::fixed << std::setprecision(9) <<imu_queue_.front().header.stamp.toSec()<<std::endl;
    // std::cout<<"current_scan_time_start_:"<<current_scan_time_start_<<std::endl;
    // std::cout<<"imu_queue_.back():"<<imu_queue_.back().header.stamp.toSec()<<std::endl;
    // std::cout<<"current_scan_time_end_:"<<current_scan_time_end_<<std::endl;
    // std::cout<<"imu_queue_.empty():"<<imu_queue_.empty()<<std::endl;
    // std::cout<<"imu_queue_.front().header.stamp.toSec() > current_scan_time_start_:"<< (imu_queue_.front().header.stamp.toSec() > current_scan_time_start_) << std::endl; 
    // std::cout<<"imu_queue_.back().header.stamp.toSec() < current_scan_time_end_:"<< (imu_queue_.back().header.stamp.toSec() < current_scan_time_end_) << std::endl; 

    // imu数据队列的头尾的时间戳要在雷达数据的时间段外
    if (imu_queue_.empty() ||
        imu_queue_.front().header.stamp.toSec() > current_scan_time_start_ ||
        imu_queue_.back().header.stamp.toSec() < current_scan_time_end_)
    {
        ROS_WARN("Waiting for IMU data ...");
        return false;
    }

    // ROS_INFO("here is while (!imu_queue_.empty())");
    // 修剪imu的数据队列，直到imu的时间接近这帧点云的时间
    while (!imu_queue_.empty())
    {   
        if (imu_queue_.front().header.stamp.toSec() < current_scan_time_start_ - 0.1)
        {
            imu_queue_.pop_front();
            // ROS_WARN("Prune imu's data queue");
        }
        else
            break;
    }

    std::cout<<"imu_queue_.size() after prune:"<<imu_queue_.size()<<std::endl;
    // ROS_INFO("here is if (imu_queue_.empty())");
    if (imu_queue_.empty())
        return false;
    current_imu_index_ = 0;

    sensor_msgs::Imu tmp_imu_msg;
    double current_imu_time, time_diff;

    // ROS_INFO("here is for (int i = 0; i < (int)imu_queue_.size(); i++)");
    for (int i = 0; i < (int)imu_queue_.size(); i++)
    {
        // std::cout<<"(int)imu_queue_.size():"<<(int)imu_queue_.size()<<std::endl;
        tmp_imu_msg = imu_queue_[i];
        current_imu_time = tmp_imu_msg.header.stamp.toSec();

        if (current_imu_time < current_scan_time_start_)
        {
            // ROS_INFO("here in the if (current_imu_time < current_scan_time_start_)");
            // 初始角度为0
            if (current_imu_index_ == 0)
            {   
                // ROS_WARN("here in the if (current_imu_index_ == 0) ");
                // imu_rot_x_[0] = 0;
                // imu_rot_y_[0] = 0;
                // imu_rot_z_[0] = 0;
                // imu_time_[0] = current_imu_time;
                // std::cout<< std::fixed << std::setprecision(9) <<"imu_time_[0]:"<<imu_time_[0]<<std::endl;
                ++current_imu_index_;
            }
            if(current_imu_time > current_scan_time_start_ - 0.01)
            {
                imu_rot_x_[0] = 0;
                imu_rot_y_[0] = 0;
                imu_rot_z_[0] = 0;
                imu_time_[0] = current_imu_time;
            }
            continue;
        }
        // ROS_INFO("here is if (current_imu_time > current_scan_time_end_)");
        // imu时间比雷达结束时间晚，就退出
        if (current_imu_time > current_scan_time_end_)
            break;
            
        // get angular velocity
        double angular_x, angular_y, angular_z;
        angular_x = tmp_imu_msg.angular_velocity.x;
        angular_y = tmp_imu_msg.angular_velocity.y;
        angular_z = tmp_imu_msg.angular_velocity.z;

        // 对imu的角速度进行积分，当前帧的角度 = 上一帧的角度 + 当前帧角速度 * (当前帧imu的时间 - 上一帧imu的时间)
        // std::cout<<"current_imu_index_:"<<current_imu_index_<<std::endl;
        double time_diff = current_imu_time - imu_time_[current_imu_index_ - 1];
        imu_rot_x_[current_imu_index_] = imu_rot_x_[current_imu_index_ - 1] + angular_x * time_diff;
        imu_rot_y_[current_imu_index_] = imu_rot_y_[current_imu_index_ - 1] + angular_y * time_diff;
        imu_rot_z_[current_imu_index_] = imu_rot_z_[current_imu_index_ - 1] + angular_z * time_diff;
        imu_time_[current_imu_index_] = current_imu_time;
        // std::cout<<"imu_rot_z_"<<current_imu_index_<<imu_rot_z_[current_imu_index_]<<std::endl;
        ++current_imu_index_;
        // std::cout<<"time diff:"<<time_diff<<std::endl;
    }

    // 对current_imu_index_进行-1操作后，current_imu_index_指向当前雷达时间内的最后一个imu数据
    --current_imu_index_;
    
    return true;
}
// 根据点云中某点的时间戳赋予其 通过插值 得到的旋转量
void OdometryKeyframeFuser::ComputeRotation(double pointTime, double *rotZCur)
{
    *rotZCur = 0;

    // 找到在　pointTime　之后的imu数据
    int imuPointerFront = 0;
    while (imuPointerFront < current_imu_index_)
    {
        if (pointTime < imu_time_[imuPointerFront])
            break;
        ++imuPointerFront;
    }

    // 如果上边的循环没进去或者到了最大执行次数，则只能近似的将当前的旋转　赋值过去
    if (pointTime > imu_time_[imuPointerFront] || imuPointerFront == 0)
    {
        *rotZCur = imu_rot_z_[imuPointerFront];
    }
    else
    {
        int imuPointerBack = imuPointerFront - 1;

        // 根据线性插值计算 pointTime 时刻的旋转
        double ratioFront = (pointTime - imu_time_[imuPointerBack]) / (imu_time_[imuPointerFront] - imu_time_[imuPointerBack]);
        double ratioBack = (imu_time_[imuPointerFront] - pointTime) / (imu_time_[imuPointerFront] - imu_time_[imuPointerBack]);

        *rotZCur = imu_rot_z_[imuPointerFront] * ratioFront + imu_rot_z_[imuPointerBack] * ratioBack;
        
    }
}

// 参数进行初始化与重置
void OdometryKeyframeFuser::ResetParameters()
{
    current_imu_index_ = 0;


    imu_time_.clear();
    imu_rot_x_.clear();
    imu_rot_y_.clear();
    imu_rot_z_.clear();

    imu_time_ = std::vector<double>(queueLength, 0);
    imu_rot_x_ = std::vector<double>(queueLength, 0);
    imu_rot_y_ = std::vector<double>(queueLength, 0);
    imu_rot_z_ = std::vector<double>(queueLength, 0);
}

//实现了激光雷达帧数据的处理流程，包括补偿、配准、关键帧融合等操作
void OdometryKeyframeFuser::processFrame(pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud, pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud_peaks, const ros::Time& t) {

  ros::Time t0 = ros::Time::now();
  Eigen::Affine3d TprevMot(Tmot);
  //补偿
  if(par.compensate){
    //radar_ccw is true 
    Compensate_rotation(*cloud, TprevMot, par.radar_ccw, t);
    Compensate_rotation(*cloud_peaks, TprevMot, par.radar_ccw, t);
  }
  
  // for (const auto& element : m_imu) {
  //   std::cout << "after Compensate_rotation m_imu::"<<element << " ";
  // } 
  // std::cout << std::endl;
  // double x = m_imu[0];
  // double y = m_imu[1];
  // double yaw = m_imu[2];
  // T_imu.translation() << x, y, 0.0;
  // T_imu.linear() = Eigen::AngleAxisd(yaw, Eigen::Vector3d::UnitZ()).toRotationMatrix();
  // std::vector<double> m_3;
  // CFEAR_Radarodometry::Affine3dToVectorXYeZ(T_imu, m_3);
  // for (const auto& element : m_3) {
  //   std::cout << "after Compensate_rotation T_imu::"<<element << " ";
  // } 
  // std::cout << std::endl;
  // //Tmot  = T_imu;
  // //TprevMot = T_imu;
  // std::vector<double> m_1, m_2;
  // CFEAR_Radarodometry::Affine3dToVectorXYeZ(Tmot, m_1); // mot 是 dx, dy, 和绕z轴的欧拉角（弧度制）
  // for (const auto& element : m_1) {
  //   std::cout << "after Compensate_rotation Tmot::"<<element << " ";
  // } 
  // std::cout << std::endl;

  // CFEAR_Radarodometry::Affine3dToVectorXYeZ(TprevMot, m_2); // mot 是 dx, dy, 和绕z轴的欧拉角（弧度制）
  // for (const auto& element : m_2) {
  //   std::cout << "after Compensate_rotation TprevMot::"<<element << " ";
  // } 
  // std::cout << std::endl;

  ResetParameters();

  //元素的类型是 Matrix6d，大小为 6x6 的矩阵
  std::vector<Matrix6d> cov_vek; 
  Covariance cov_sampled;
  std::vector<CFEAR_Radarodometry::MapNormalPtr> scans_vek;
  std::vector<Eigen::Affine3d> T_vek;
  ros::Time t1 = ros::Time::now();

  //std::cout << "par.res: " << par.res << std::endl;
  // 创建当前帧的地图点云数据对象
  CFEAR_Radarodometry::MapNormalPtr Pcurrent = CFEAR_Radarodometry::MapNormalPtr(new MapPointNormal(cloud, par.res, Eigen::Vector2d(0,0), par.weight_intensity_, par.use_raw_pointcloud));

  ros::Time t2 = ros::Time::now();
  Eigen::Affine3d Tguess;
  if(par.use_guess)
    Tguess = T_prev*TprevMot;          // T_prev = Tcurrent
  else
    Tguess = T_prev;

  //第一帧
  if(keyframes_.empty()){
    scan_ = RadarScan(Eigen::Affine3d::Identity(), Eigen::Affine3d::Identity(), cloud_peaks, cloud, Pcurrent, t);
    AddToGraph(keyframes_, scan_, Eigen::Matrix<double,6,6>::Identity());
    updated = true;
    AddToReference(keyframes_, scan_, par.submap_scan_size);
    return;
  }
  else
  //格式化
    FormatScans(keyframes_, Pcurrent, Tguess, cov_vek, scans_vek, T_vek);

  //Only for generating plots


  bool success = true;
  if(!par.disable_registration)
    bool success = radar_reg->Register(scans_vek, T_vek, cov_vek, par.soft_constraint);

  ros::Time t3 = ros::Time::now();

  if(success==false){
    cout<<"registration failure"<<radar_reg->summary_.FullReport()<<endl;
    exit(0);
  }
  //配准成功，更新
  Tcurrent = T_vek.back();
  cov_current = cov_vek.back();
  Eigen::Affine3d Tmot_current = T_prev.inverse()*Tcurrent;
  if(!AccelerationVelocitySanityCheck(Tmot, Tmot_current)) //Tmot 是 Tmot_prev，Tmot_current 是 Tmot_curr
    Tcurrent = Tguess; //Insane acceleration and speed, lets use the guess.
  Tmot = T_prev.inverse()*Tcurrent;

  // Try to approximate the covariance by the cost-sampling approach
  if(par.estimate_cov_by_sampling){
      if(approximateCovarianceBySampling(scans_vek, T_vek, cov_sampled)){ // if success, cov_sampled contains valid data
          cov_current = cov_sampled;
          cov_vek.back() = cov_sampled;
      }
  }
  //当前帧地图点云
  MapPointNormal::PublishMap("/current_normals", Pcurrent, Tcurrent, par.odometry_link_id,-1,0.5);
  pcl::PointCloud<pcl::PointXYZI> cld_latest = FormatScanMsg(*cloud, Tcurrent);
  nav_msgs::Odometry msg_current = FormatOdomMsg(Tcurrent, Tmot, t, cov_current);
  //radar_registered
  pubsrc_cloud_latest.publish(cld_latest);
  //radar_odom
  pose_current_publisher.publish(msg_current);
  if(par.publish_tf_){
    geometry_msgs::TransformStamped transformStamped;
    transformStamped.header.stamp = msg_current.header.stamp;
    transformStamped.header.frame_id = msg_current.header.frame_id;

    tf::Transform Tf;
    std::vector<tf::StampedTransform> trans_vek;
    tf::transformEigenToTF(Tcurrent, Tf);
    trans_vek.push_back(tf::StampedTransform(Tf, t, par.odometry_link_id, "radar_link"));
    Tbr.sendTransform(trans_vek);
  }
  //当前帧和上一关键帧之间的diff
  const Eigen::Affine3d Tkeydiff = keyframes_.back().GetPose().inverse()*Tcurrent;
  bool fuse = KeyFrameBasedFuse(Tkeydiff, par.use_keyframe, par.min_keyframe_dist_, par.min_keyframe_rot_deg_);


  CFEAR_Radarodometry::timing.Document("velocity", Tmot.translation().norm()/Tsensor);

  //更新了关键帧数
  if(success && fuse){
    //cout << "fuse" <<endl;
    distance_traveled += Tkeydiff.translation().norm();
    Tprev_fused = Tcurrent;
    pcl::PointCloud<pcl::PointXYZI> cld_keyframe = FormatScanMsg(*cloud, Tcurrent);
    nav_msgs::Odometry msg_keyframe = FormatOdomMsg(Tcurrent, Tkeydiff, t, cov_vek.back());
    pub_cloud_keyframe.publish(cld_keyframe);
    pose_keyframe_publisher.publish(msg_keyframe);

    frame_nr_++;
    scan_ = RadarScan(Tcurrent, TprevMot, cloud_peaks, cloud, Pcurrent, t);
    AddToGraph(keyframes_, scan_, cov_current);
    AddToReference(keyframes_,scan_, par.submap_scan_size);
    updated = true;

  }
  //else
    //cout << "no fuse" <<endl;
  ros::Time t4 = ros::Time::now();
  CFEAR_Radarodometry::timing.Document("compensate", ToMs(t1-t0));
  CFEAR_Radarodometry::timing.Document("build_normals", ToMs(t2-t1));
  CFEAR_Radarodometry::timing.Document("register", ToMs(t3-t2));
  CFEAR_Radarodometry::timing.Document("publish_etc", ToMs(t4-t3));
  T_prev = Tcurrent;

}

//通过对采样点进行线性最小二乘拟合来近似计算协方差矩阵
bool OdometryKeyframeFuser::approximateCovarianceBySampling(std::vector<CFEAR_Radarodometry::MapNormalPtr> &scans_vek,
                                                            const std::vector<Eigen::Affine3d> &T_vek,
                                                            Covariance &cov_sampled){
  bool cov_sampled_success = true;
  string path;   // for dumping samples to a file
  std::ofstream cov_samples_file;

  std::vector<Eigen::Affine3d> T_vek_copy(T_vek);
  Eigen::Affine3d T_best_guess = T_vek_copy.back();

  if(par.cov_samples_to_file_as_well){
    path = par.cov_sampling_file_directory + string("/cov_samples_") + std::to_string(nr_callbacks_) + string(".csv");
    cov_samples_file.open(path);
  }

  double xy_sample_range = par.cov_sampling_xy_range*0.5; // sampling in x and y axis around the estimated pose
  double theta_range = par.cov_sampling_yaw_range*0.5;  // sampling on the yaw axis plus minus
  unsigned int number_of_steps_per_axis = par.cov_sampling_samples_per_axis;
  unsigned int number_of_samples = number_of_steps_per_axis*number_of_steps_per_axis*number_of_steps_per_axis;

  Eigen::Affine3d sample_T = Eigen::Affine3d::Identity();
  double sample_cost = 0;  // return of the getCost function
  std::vector<double> residuals; // return of the getCost function
  Eigen::VectorXd samples_x_values(number_of_samples);
  Eigen::VectorXd samples_y_values(number_of_samples);
  Eigen::VectorXd samples_yaw_values(number_of_samples);
  Eigen::VectorXd samples_cost_values(number_of_samples);

  std::vector<double> xy_samples = linspace<double>(-xy_sample_range, xy_sample_range, number_of_steps_per_axis);
  std::vector<double> theta_samples = linspace<double>(-theta_range, theta_range, number_of_steps_per_axis);

  // Sample the cost function according to the settings, optionally dump the samples into a file
  int vector_pointer = 0;
  for (int theta_sample_id = 0; theta_sample_id < number_of_steps_per_axis; theta_sample_id++) {
    for (int x_sample_id = 0; x_sample_id < number_of_steps_per_axis; x_sample_id++) {
      for (int y_sample_id = 0; y_sample_id < number_of_steps_per_axis; y_sample_id++) {

        sample_T.translation() = Eigen::Vector3d(xy_samples[x_sample_id],
                                                 xy_samples[y_sample_id],
                                                 0.0) + T_best_guess.translation();
        sample_T.linear() = Eigen::AngleAxisd(theta_samples[theta_sample_id],
                                              Eigen::Vector3d(0.0, 0.0, 1.0)) * T_best_guess.linear();

        T_vek_copy.back() = sample_T;
        radar_reg->GetCost(scans_vek, T_vek_copy, sample_cost, residuals);

        samples_x_values[vector_pointer] = xy_samples[x_sample_id];
        samples_y_values[vector_pointer] = xy_samples[y_sample_id];
        samples_yaw_values[vector_pointer] = theta_samples[theta_sample_id];
        samples_cost_values[vector_pointer] = sample_cost;
        vector_pointer ++;

        if(par.cov_samples_to_file_as_well) {
            cov_samples_file << xy_samples[x_sample_id] << " " << xy_samples[y_sample_id] <<
                             " " << theta_samples[theta_sample_id] << " " << sample_cost << std::endl;
        }
      }
    }
  }
  if(cov_samples_file.is_open()) cov_samples_file.close();

  //Find the approximating quadratic function by linear least squares
  // f(x,y,z) = ax^2 + by^2 + cz^2 + dxy + eyz + fzx + gx+ hy + iz + j
  // A = [x^2, y^2, z^2, xy, yz, zx, x, y, z, 1]
  Eigen::MatrixXd A(number_of_samples, 10);
  A << samples_x_values.array().square().matrix(),
          samples_y_values.array().square().matrix(),
          samples_yaw_values.array().square().matrix(),
          (samples_x_values.array()*samples_y_values.array()).matrix(),
          (samples_y_values.array()*samples_yaw_values.array()).matrix(),
          (samples_yaw_values.array()*samples_x_values.array()).matrix(),
          samples_x_values,
          samples_y_values,
          samples_yaw_values,
          Eigen::MatrixXd::Ones(number_of_samples,1);

  Eigen::VectorXd quad_func_coefs = A.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(samples_cost_values);

  // With the coefficients, we can contruct the Hessian matrix (constant for a given function)
  Eigen::Matrix3d hessian_matrix;
  hessian_matrix << 2*quad_func_coefs[0],   quad_func_coefs[3],   quad_func_coefs[5],
          quad_func_coefs[3], 2*quad_func_coefs[1],   quad_func_coefs[4],
          quad_func_coefs[5],   quad_func_coefs[4], 2*quad_func_coefs[2];

  // We need to check if the approximating function is convex (all eigs positive, we don't went the zero eigs either)
  Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> eigensolver(hessian_matrix);
  Eigen::Vector3d eigValues;
  Eigen::Matrix3d covariance_3x3;

  if (eigensolver.info() != Eigen::Success) {
    cov_sampled_success = false;
    std::cout << "Covariance sampling warning: Eigenvalues search failed." << std::endl;
  }
  else{
    eigValues = eigensolver.eigenvalues();
    if(eigValues[0] <= 0.0 || eigValues[1] <= 0.0 || eigValues[2] <= 0.0){
        cov_sampled_success = false;
        std::cout << "Covariance sampling warning: Quadratic approximation not convex. Sampling will not be used for this scan." << std::endl;
    }
    else{
      // Compute the covariance from the hessian and scale by the score
      double score_scale = 1.0;
      if(radar_reg->GetCovarianceScaler(score_scale)) {

        covariance_3x3 = 2.0 * hessian_matrix.inverse() * score_scale * par.cov_sampling_covariance_scaler;

        //We need to construct the full 6DOF cov matrix
        cov_sampled = Eigen::Matrix<double, 6, 6>::Identity();
        cov_sampled.block<2, 2>(0, 0) = covariance_3x3.block<2, 2>(0, 0);
        cov_sampled(5, 5) = covariance_3x3(2, 2);
        cov_sampled(0, 5) = covariance_3x3(0, 2);
        cov_sampled(1, 5) = covariance_3x3(1, 2);
        cov_sampled(5, 0) = covariance_3x3(2, 0);
        cov_sampled(5, 1) = covariance_3x3(2, 1);
      }
      else cov_sampled_success = false;
    }
  }
  return cov_sampled_success;
}

void OdometryKeyframeFuser::ImuCallback(const sensor_msgs::ImuConstPtr& _imu_msg)
{
  std::lock_guard<std::mutex> lock(imu_lock_);
  imu_queue_.push_back(*_imu_msg);
}

void OdometryKeyframeFuser::pointcloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg_in){
  updated = false;
  //  cout<<"callback"<<endl;
  ros::Time t1 = ros::Time::now();
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_peaks(new pcl::PointCloud<pcl::PointXYZI>());
  pcl::fromROSMsg (*msg_in, *cloud);
  pcl_conversions::toPCL(msg_in->header.stamp, cloud->header.stamp);

  this->processFrame(cloud, cloud_peaks, msg_in->header.stamp);
  nr_callbacks_++;
  ros::Time t2 = ros::Time::now();
  CFEAR_Radarodometry::timing.Document("Registration-full",CFEAR_Radarodometry::ToMs(t2-t1));
}


void OdometryKeyframeFuser::pointcloudCallback(pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud_filtered,  pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud_filtered_peaks,  Eigen::Affine3d &Tcurr, const ros::Time& t){
  ros::Time t1 = ros::Time::now();
  updated = false;
  this->processFrame(cloud_filtered, cloud_filtered_peaks, t);
  nr_callbacks_++;
  Tcurr = Tcurrent;
  ros::Time t2 = ros::Time::now();
  CFEAR_Radarodometry::timing.Document("Registration",CFEAR_Radarodometry::ToMs(t2-t1));

}

void OdometryKeyframeFuser::pointcloudCallback(pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud_filtered,  pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud_filtered_peaks,  Eigen::Affine3d &Tcurr, const ros::Time& t, Covariance &cov_curr){
    pointcloudCallback(cloud_filtered, cloud_filtered_peaks, Tcurr, t);
    cov_curr = cov_current;
}


void OdometryKeyframeFuser::PrintSurface(const std::string& path, const Eigen::MatrixXd& surface){
  std::ofstream myfile;
  myfile.open (path);
  for(int i=0;i<surface.rows();i++){
    for(int j=0;j<surface.cols();j++){
      if(j==surface.cols()-1)
        myfile<<surface(i,j)<<std::endl;
      else
        myfile<<surface(i,j)<<" ";
    }
  }
  myfile.close();
}

void OdometryKeyframeFuser::AddToGraph(PoseScanVector& reference, RadarScan& scan,  const Eigen::Matrix<double,6,6>& Cov){
  if(frame_nr_ == 0){
    graph_.push_back(std::make_pair(scan,std::vector<Constraint3d>()));
  }
  else{
    std::vector<Constraint3d> constraints;
    for(auto itr = reference.rbegin() ; itr!=reference.rend() ; itr++){
      const Eigen::Affine3d Tfrom = scan.GetPose();
      const Eigen::Affine3d Tto = itr->GetPose();
      Eigen::Affine3d Tdiff = Tfrom.inverse()*Tto;
      Eigen::Matrix<double,6,6> C = Cov;
      C.block<3,3>(0,0) = Tfrom.inverse().rotation()*Cov.block<3,3>(0,0)*Tfrom.inverse().rotation().transpose(); //Change frame to Tprev
      constraints.push_back({scan.idx_, itr->idx_, PoseEigToCeres(Tdiff), C.inverse(), ConstraintType::odometry});
      break;
    }
    graph_.push_back(std::make_pair(scan, constraints));
  }
}
void OdometryKeyframeFuser::AddGroundTruth(poseStampedVector& gt_vek){
  std::map<unsigned long,Pose3d> stamp_map;
  for (auto && gt : gt_vek ){ // construct map of ground truth poses
    stamp_map[gt.t.toNSec()] = PoseEigToCeres(gt.pose);
    //cout << "gt : " << gt.second.toNSec() << endl;
  }

  for (auto itr = graph_.begin() ; itr != graph_.end() ; itr++) { // for each pose, add to ground truth
    //cout << "est: " << itr->first.stamp_ << endl;
    if(stamp_map.find( itr->first.stamp_) != stamp_map.end()){ // if estimated exist in ground truth map
      itr->first.Tgt = stamp_map[itr->first.stamp_]; // add ground truth pose;
      itr->first.has_Tgt_ = true;
    }
    /*else
      //std::cerr << "cannot find pose " << itr->first.stamp_<< " in simple graph" << std::endl;
    */
  }
}

void OdometryKeyframeFuser::SaveGraph(const std::string& path){
  if(par.store_graph)
    CFEAR_Radarodometry::SaveSimpleGraph(path, graph_);
}

void AddToReference(PoseScanVector& reference, RadarScan& scan, size_t submap_scan_size){

  reference.push_back(scan);
  if(reference.size() > submap_scan_size){
    reference.erase(reference.begin());
  }
}

void FormatScans(const PoseScanVector& reference,
                 const CFEAR_Radarodometry::MapNormalPtr& Pcurrent,
                 const Eigen::Affine3d& Tcurrent,
                 std::vector<Matrix6d>& cov_vek,
                 std::vector<MapNormalPtr>& scans_vek,
                 std::vector<Eigen::Affine3d>& T_vek
                 ){

  for (int i=0;i<reference.size();i++) {
    cov_vek.push_back(Identity66);
    scans_vek.push_back(reference[i].cloud_normal_);
    T_vek.push_back(reference[i].GetPose());
  }
  cov_vek.push_back(Identity66);
  scans_vek.push_back(Pcurrent);
  T_vek.push_back(Tcurrent);
}


//生成指定范围内均匀分布的数字序列
template<typename T>
std::vector<double> linspace(T start_in, T end_in, int num_in)
{

    std::vector<double> linspaced;

    double start = static_cast<double>(start_in);
    double end = static_cast<double>(end_in);
    double num = static_cast<double>(num_in);

    if (num == 0) { return linspaced; }
    if (num == 1)
    {
        linspaced.push_back(start);
        return linspaced;
    }

    double delta = (end - start) / (num - 1);

    for(int i=0; i < num-1; ++i)
    {
        linspaced.push_back(start + delta * i);
    }
    linspaced.push_back(end); // I want to ensure that start and end
    // are exactly the same as the input
    return linspaced;
}

}
